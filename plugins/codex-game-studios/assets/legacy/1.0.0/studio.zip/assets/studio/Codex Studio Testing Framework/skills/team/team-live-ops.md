# Skill Test Spec: $team-live-ops

## Codex Runtime Contract

- Runtime skill: `.agents/skills/team-live-ops/SKILL.md`
- Runtime name: `team-live-ops`
- Runtime trigger description: `"Use when a season, event, or live content update needs coordinated design, economy, analytics, communication, writing, and narrative planning."`
- Native invocation: `$team-live-ops`
- Discovery contract: only `name` and `description` are required in YAML frontmatter; invocation arguments and permissions belong in the workflow body or runtime policy.
- Structured decisions: when `request_user_input` is appropriate, each call contains 1–3 questions and each question contains 2–3 options. Ask one decision per turn; sequence unrelated decisions across turns.
- Custom-agent delegation: delegate only to a direct child custom agent. The maximum delegation depth is 1. Each child returns scoped findings and evidence, and the parent agent synthesizes the final result and owns user interaction.
- Methodology: retain five cases covering the happy path, a blocked/failure path, a mode or boundary variant, an edge case, and delegation/gate behavior.

---


## Skill Summary

`$team-live-ops` is tested against the exact runtime discovery contract above. The five
cases below preserve its domain fixtures, expected outputs, verdict vocabulary, review
modes, and edge conditions.

Validation is read-only. If the workflow writes, the parent first presents one
complete proposed changeset containing every target path and material edit; any
new path or scope expansion requires fresh approval. If it delegates, direct
children return scoped evidence and the parent synthesizes the result.

---

## Static Assertions (Structural)

- [ ] Runtime YAML frontmatter has only the required discovery fields `name` and `description`, and both match the contract above
- [ ] Has ≥2 phase headings
- [ ] Contains verdict keywords: COMPLETE, BLOCKED
- [ ] The parent presents one complete proposed changeset containing every target path and material edit, then obtains approval before any write
- [ ] Has a File Write Protocol section stating that the orchestrator does not write files directly
- [ ] Has a next-step handoff at the end referencing `$design-review`, `$sprint-plan`, and `$team-release`
- [ ] Uses `request_user_input` at phase transitions to capture user approval before proceeding
- [ ] States explicitly that Phases 3 and 4 can run simultaneously (parallel spawning)
- [ ] Error recovery section present (or implied through BLOCKED handling)
- [ ] Output documents section specifies paths under `design/live-ops/seasons/`

---

## Test Cases

### Case 1: Happy Path — All 7 phases complete, season plan produced

**Fixture:**
- `design/live-ops/economy-rules.md` exists with current economy configuration
- `design/live-ops/ethics-policy.md` exists with the project ethics policy
- Game concept document exists at its standard path
- No existing season documents for the new season name being planned

**Input:** `$team-live-ops "Season 2: The Frozen Wastes"`

**Expected behavior:**
1. Phase 1: Delegates the season brief to `live-ops-designer`; the parent receives and presents the scoped result
2. request_user_input: user approves Phase 1 output before Phase 2 begins
3. Phase 2: Delegates narrative framing to `narrative-director`; the parent receives and presents the theme, story hook, and lore connections
4. Phase 3 and 4 (parallel): Spawns `economy-designer` and `analytics-engineer` simultaneously via two child-agent delegations before waiting for either result; economy-designer reads `design/live-ops/economy-rules.md`
5. Phase 5: Spawns `narrative-director` and `writer` in parallel to produce in-game narrative text and player-facing copy; both read Phase 2 narrative framing doc
6. Phase 6: Spawns `community-manager` as a direct child custom agent; reads season brief, economy design, and narrative framing; produces communication calendar with draft copy
7. Phase 7: Collects all phase outputs; presents consolidated season plan summary including economy health check, analytics readiness, ethics review, and open questions
8. request_user_input: user approves the full season plan
9. The parent presents one complete proposed changeset containing every target path and material edit, then obtains approval before any write.
10. Verdict: COMPLETE — season plan produced and handed off for production

**Assertions:**
- [ ] All 7 phases execute in order; Phase 3 and 4 are issued as parallel child-agent delegations
- [ ] Phase 7 consolidated summary includes all six sections (season brief, narrative framing, economy design, analytics plan, content inventory, communication calendar)
- [ ] Ethics review section in Phase 7 explicitly references `design/live-ops/ethics-policy.md`
- [ ] Three output documents written to `design/live-ops/seasons/` with correct naming convention
- [ ] File writes are delegated to child custom agents — orchestrator does not write directly
- [ ] Verdict: COMPLETE appears in final output
- [ ] Next steps reference `$design-review`, `$sprint-plan`, and `$team-release`

---

### Case 2: Ethics Violation Found — Reward element violates ethics policy

**Fixture:**
- All standard live-ops fixtures present (economy-rules.md, ethics-policy.md)
- `design/live-ops/ethics-policy.md` explicitly prohibits loot boxes targeting players under 18
- economy-designer (Phase 3) proposes a "Mystery Chest" mechanic with randomized premium rewards and no pity timer

**Input:** `$team-live-ops "Season 3: Shadow Tournament"`

**Expected behavior:**
1. Phases 1–4 proceed normally; economy-designer proposes Mystery Chest mechanic
2. Phase 7: Orchestrator reviews Phase 3 output against ethics policy; identifies Mystery Chest as a violation of the "no untransparent random premium rewards" rule in the ethics policy
3. Ethics review section of the Phase 7 summary flags the violation explicitly: "ETHICS FLAG: Mystery Chest mechanic in Phase 3 economy design violates [policy rule]. Approval is blocked until this is resolved."
4. request_user_input presented with resolution options before season plan approval is offered
5. Skill does NOT issue a COMPLETE verdict or write output documents until the ethics violation is resolved or explicitly waived by the user

**Assertions:**
- [ ] Phase 7 ethics review section explicitly names the violating element and the policy rule it breaks
- [ ] Skill does not auto-approve the season plan when an ethics violation is present
- [ ] request_user_input is used to surface the violation and offer resolution options (revise economy design, override with documented rationale, cancel)
- [ ] Output documents are NOT written while the violation is unresolved
- [ ] If user chooses to revise: skill re-spawns economy-designer to produce a corrected design before returning to Phase 7 review
- [ ] Verdict: COMPLETE is only issued after the ethics flag is cleared

---

### Case 3: No Argument — Usage guidance shown

**Fixture:**
- Any project state

**Input:** `$team-live-ops` (no argument)

**Expected behavior:**
1. Phase 1: No argument detected
2. Outputs: "Usage: `$team-live-ops [season name or event description]` — Provide the name or description of the season or live event to plan."
3. Skill exits immediately without spawning any subagents

**Assertions:**
- [ ] Skill does NOT guess a season name or fabricate a scope
- [ ] Error message includes the correct usage format with the invocation arguments
- [ ] No child-agent delegations are issued before the argument check fails
- [ ] No files are read or written

---

### Case 4: Parallel Phase Validation — Phases 3 and 4 run simultaneously

**Fixture:**
- All standard live-ops fixtures present
- Phase 1 (season brief) and Phase 2 (narrative framing) already approved
- Phase 3 (economy-designer) and Phase 4 (analytics-engineer) inputs are independent of each other

**Input:** `$team-live-ops "Season 1: The First Thaw"` (observed at Phase 3/4 transition)

**Expected behavior:**
1. After Phase 2 is approved by the user, the orchestrator issues both child-agent delegations (economy-designer and analytics-engineer) before awaiting either result
2. Both agents receive the season brief as context; analytics-engineer does NOT wait for economy-designer output to begin
3. Economy-designer output and analytics-engineer output are collected together before Phase 5 begins
4. If one of the two parallel agents blocks, the other continues; a partial result is reported

**Assertions:**
- [ ] Both child-agent delegations for Phase 3 and Phase 4 are issued before either result is awaited — they are not sequential
- [ ] Analytics-engineer prompt does NOT include economy-designer output as a required input (the inputs are independent)
- [ ] If economy-designer blocks but analytics-engineer succeeds, analytics output is preserved and the block is surfaced via request_user_input
- [ ] Phase 5 does not begin until BOTH Phase 3 and Phase 4 results are collected
- [ ] Skill documentation explicitly states "Phases 3 and 4 can run simultaneously"

---

### Case 5: Missing Ethics Policy — `design/live-ops/ethics-policy.md` does not exist

**Fixture:**
- `design/live-ops/economy-rules.md` exists
- `design/live-ops/ethics-policy.md` does NOT exist
- All other fixtures are present

**Input:** `$team-live-ops "Season 4: Desert Heat"`

**Expected behavior:**
1. Phases 1–4 proceed; economy-designer and analytics-engineer are given the ethics policy path but it is absent
2. Phase 7: Orchestrator attempts to run ethics review; detects that `design/live-ops/ethics-policy.md` is missing
3. Phase 7 summary includes a gap flag: "ETHICS REVIEW SKIPPED: `design/live-ops/ethics-policy.md` not found. Economy design was not reviewed against an ethics policy. Recommend creating one before production begins."
4. Skill still completes the season plan and reaches COMPLETE verdict, but the gap is prominently flagged in the output and in the season design document
5. Next steps include a recommendation to create the ethics policy document

**Assertions:**
- [ ] Skill does NOT error out when the ethics policy file is missing
- [ ] Skill does NOT fabricate ethics policy rules in the absence of the file
- [ ] Phase 7 summary explicitly notes that ethics review was skipped and why
- [ ] Verdict: COMPLETE is still reachable despite the missing file
- [ ] Gap flag appears in the season design output document (not just in conversation)
- [ ] Next steps recommend creating `design/live-ops/ethics-policy.md`

---

## Protocol Compliance

- [ ] `request_user_input` used at every phase transition — user approves before the next phase begins
- [ ] Phases 3 and 4 are always spawned in parallel, not sequentially
- [ ] File Write Protocol: orchestrator never calls Write/Edit directly — all writes are delegated to child custom agents
- [ ] The parent presents one complete proposed changeset containing every target path and material edit, then obtains approval before any write
- [ ] Ethics review in Phase 7 always references the ethics policy file path explicitly
- [ ] Error recovery: any BLOCKED agent is surfaced immediately with request_user_input options (skip / retry / stop)
- [ ] Partial reports are produced if any phase blocks — work is never discarded
- [ ] Verdict: COMPLETE only after user approves the consolidated season plan; BLOCKED if any unresolved ethics violation exists
- [ ] Next steps always include `$design-review`, `$sprint-plan`, and `$team-release`

---

## Coverage Notes

- Phase 5 parallel spawning (narrative-director + writer) follows the same pattern as Phases 3/4 but is not separately tested here — it uses the same parallel direct-child delegation protocol validated in Case 4.
- The "economy-rules.md absent" edge case is not separately tested — it would surface as a BLOCKED result from economy-designer and follow the standard error recovery path tested implicitly in Case 4.
- The full content writing pipeline (Phase 5 output validation) is validated implicitly by the Case 1 happy path consolidated summary check.
- Community manager communication calendar format (pre-launch, launch day, mid-season, final week) is validated implicitly by Case 1; no separate edge case is needed.
